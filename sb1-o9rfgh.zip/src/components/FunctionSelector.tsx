import React from 'react';

interface FunctionSelectorProps {
  functions: { name: string; icon: React.ReactNode }[];
  selectedFunction: string;
  setSelectedFunction: (func: string) => void;
}

const FunctionSelector: React.FC<FunctionSelectorProps> = ({ functions, selectedFunction, setSelectedFunction }) => {
  return (
    <div className="mb-6">
      <label className="block text-sm font-medium text-gray-700 mb-2">Select Function</label>
      <div className="grid grid-cols-2 gap-4 sm:grid-cols-3">
        {functions.map((func) => (
          <button
            key={func.name}
            onClick={() => setSelectedFunction(func.name)}
            className={`flex items-center justify-center px-4 py-2 border rounded-md shadow-sm text-sm font-medium ${
              selectedFunction === func.name
                ? 'bg-indigo-600 text-white'
                : 'bg-white text-gray-700 hover:bg-gray-50'
            }`}
          >
            {func.icon}
            <span className="ml-2">{func.name}</span>
          </button>
        ))}
      </div>
    </div>
  );
};

export default FunctionSelector;