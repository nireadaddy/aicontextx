import React, { useState } from 'react';
import { OpenAI } from 'openai';
import { Brain, Type, FileText, Hash, BarChart2, Tag } from 'lucide-react';
import ModelSelector from './components/ModelSelector';
import FunctionSelector from './components/FunctionSelector';
import InputForm from './components/InputForm';
import OutputDisplay from './components/OutputDisplay';

const openai = new OpenAI({
  apiKey: import.meta.env.VITE_OPENAI_API_KEY,
  dangerouslyAllowBrowser: true
});

const functions = [
  { name: 'Keyword Suggestion', icon: <Brain size={24} /> },
  { name: 'Title Generation', icon: <Type size={24} /> },
  { name: 'Meta Description Generation', icon: <FileText size={24} /> },
  { name: 'Blog Content Creation', icon: <FileText size={24} /> },
  { name: 'Tag Generation', icon: <Tag size={24} /> },
  { name: 'Density Keyword Analysis', icon: <BarChart2 size={24} /> },
];

const models = ['gpt-3.5-turbo', 'gpt-4'];

function App() {
  const [selectedFunction, setSelectedFunction] = useState(functions[0].name);
  const [selectedModel, setSelectedModel] = useState(models[0]);
  const [input, setInput] = useState('');
  const [output, setOutput] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setOutput('');

    try {
      const response = await openai.chat.completions.create({
        model: selectedModel,
        messages: [
          { role: 'system', content: `You are an AI assistant specialized in ${selectedFunction}.` },
          { role: 'user', content: generatePrompt(selectedFunction, input) },
        ],
      });

      setOutput(response.choices[0].message.content || 'No response generated.');
    } catch (error) {
      console.error('Error:', error);
      setOutput('An error occurred while processing your request.');
    } finally {
      setIsLoading(false);
    }
  };

  const generatePrompt = (func: string, userInput: string) => {
    switch (func) {
      case 'Keyword Suggestion':
        return `Suggest 5-10 relevant keywords for the topic: "${userInput}"`;
      case 'Title Generation':
        return `Generate 5 catchy titles for an article about: "${userInput}"`;
      case 'Meta Description Generation':
        return `Write a compelling meta description (150-160 characters) for a webpage about: "${userInput}"`;
      case 'Blog Content Creation':
        return `Write a 300-word blog post about: "${userInput}"`;
      case 'Tag Generation':
        return `Generate 5-10 relevant tags for a blog post about: "${userInput}"`;
      case 'Density Keyword Analysis':
        return `Analyze the keyword density of the following text and suggest improvements:\n\n${userInput}`;
      default:
        return userInput;
    }
  };

  return (
    <div className="min-h-screen bg-gray-100 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-3xl mx-auto">
        <h1 className="text-3xl font-bold text-center text-gray-900 mb-8">AI Content Generator</h1>
        <div className="bg-white shadow-md rounded-lg p-6">
          <ModelSelector models={models} selectedModel={selectedModel} setSelectedModel={setSelectedModel} />
          <FunctionSelector functions={functions} selectedFunction={selectedFunction} setSelectedFunction={setSelectedFunction} />
          <InputForm input={input} setInput={setInput} handleSubmit={handleSubmit} isLoading={isLoading} />
          <OutputDisplay output={output} isLoading={isLoading} />
        </div>
      </div>
    </div>
  );
}

export default App;