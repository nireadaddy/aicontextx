'use client'

import { useState, useEffect } from 'react'
import { Eye, EyeOff, Save, Key, CheckCircle, XCircle } from 'lucide-react'
import { motion } from 'framer-motion'
import { toast } from 'react-hot-toast'
import { useRouter } from 'next/navigation'
import { useApiKey } from '../hooks/useApiKey'

export default function ApiKeyPage() {
  const [showApiKey, setShowApiKey] = useState(false)
  const [inputApiKey, setInputApiKey] = useState('')
  const router = useRouter()
  const { apiKey, updateApiKey } = useApiKey()

  useEffect(() => {
    setInputApiKey(apiKey)
  }, [apiKey])

  const saveApiKey = () => {
    if (inputApiKey.trim() === '') {
      toast.error('Please enter a valid API key')
      return
    }
    updateApiKey(inputApiKey)
    toast.success('API key saved successfully!')
  }

  return (
    <div className="max-w-md mx-auto px-4 py-8">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="bg-white dark:bg-gray-800 rounded-lg shadow-lg p-6"
      >
        <div className="flex items-center justify-center mb-6">
          <Key size={32} className="text-blue-500 mr-2" />
          <h1 className="text-2xl font-bold text-gray-800 dark:text-gray-200">API Key Management</h1>
        </div>
        
        <div className="mb-6">
          <label htmlFor="apiKey" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
            OpenAI API Key
          </label>
          <div className="mt-1 relative rounded-md shadow-sm">
            <input
              type={showApiKey ? 'text' : 'password'}
              name="apiKey"
              id="apiKey"
              className="focus:ring-blue-500 focus:border-blue-500 block w-full pr-10 sm:text-sm border-gray-300 dark:border-gray-600 rounded-md dark:bg-gray-700 dark:text-white transition-colors duration-200"
              placeholder="Enter your OpenAI API key"
              value={inputApiKey}
              onChange={(e) => setInputApiKey(e.target.value)}
            />
            <button
              type="button"
              className="absolute inset-y-0 right-0 pr-3 flex items-center text-gray-400 hover:text-gray-500 dark:hover:text-gray-300"
              onClick={() => setShowApiKey(!showApiKey)}
            >
              {showApiKey ? <EyeOff size={20} /> : <Eye size={20} />}
            </button>
          </div>
        </div>
        <motion.button
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          onClick={saveApiKey}
          className="flex items-center justify-center w-full bg-blue-500 text-white py-2 px-4 rounded-md hover:bg-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-opacity-50 transition duration-200"
        >
          <Save size={20} className="mr-2" />
          Save API Key
        </motion.button>
        
        <div className={`mt-4 p-2 rounded-md flex items-center justify-center ${apiKey ? 'bg-[#ccfbf1] text-[#5eead4]' : 'bg-red-100 text-red-500'}`}>
          {apiKey ? (
            <>
              <CheckCircle size={20} className="mr-2" />
              <span className="font-medium">API Key Ready</span>
            </>
          ) : (
            <>
              <XCircle size={20} className="mr-2" />
              <span className="font-medium">No API Key Set</span>
            </>
          )}
        </div>
      </motion.div>
    </div>
  )
}