import React, { useState } from 'react'
import { ArrowRight, X } from 'lucide-react'
import { motion, AnimatePresence } from 'framer-motion'
import { useRouter } from 'next/navigation'

interface KeywordHistoryTableProps {
  history: { mainKeyword: string; relatedKeywords: string[]; date: string }[]
}

const KeywordHistoryTable: React.FC<KeywordHistoryTableProps> = ({ history }) => {
  const [selectedKeyword, setSelectedKeyword] = useState<string | null>(null)
  const router = useRouter()

  const handleDetailsClick = (keyword: string) => {
    setSelectedKeyword(keyword)
  }

  const closePopup = () => {
    setSelectedKeyword(null)
  }

  const handleGenerateContent = () => {
    if (selectedKeyword) {
      router.push(`/seo-generator?keyword=${encodeURIComponent(selectedKeyword)}`)
      closePopup()
    }
  }

  return (
    <div className="bg-white dark:bg-gray-800 shadow-md rounded-lg overflow-hidden">
      <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
        <thead className="bg-gray-50 dark:bg-gray-700">
          <tr>
            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">Main Keyword</th>
            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider w-1/3">Related Keywords</th>
            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">Date</th>
            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">Action</th>
          </tr>
        </thead>
        <tbody className="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
          {history.map((entry, index) => (
            <tr key={index}>
              <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900 dark:text-gray-100">{entry.mainKeyword}</td>
              <td className="px-6 py-4 text-sm text-gray-500 dark:text-gray-300 max-w-xs">
                <div className="break-words">{entry.relatedKeywords.join(', ')}</div>
              </td>
              <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-300">{entry.date}</td>
              <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                <button
                  onClick={() => handleDetailsClick(entry.mainKeyword)}
                  className="text-blue-500 hover:text-blue-600 dark:hover:text-blue-400 flex items-center"
                >
                  Generate Content <ArrowRight size={16} className="ml-1" />
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      <AnimatePresence>
        {selectedKeyword && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50"
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="bg-white dark:bg-gray-800 rounded-lg p-8 max-w-md w-full relative"
            >
              <button
                onClick={closePopup}
                className="absolute top-4 right-4 text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200"
              >
                <X size={24} />
              </button>
              <h2 className="text-2xl font-bold mb-4 text-gray-800 dark:text-gray-200">
                Generate Content for "{selectedKeyword}"
              </h2>
              <p className="text-gray-600 dark:text-gray-400 mb-6">
                Click the button below to go to the SEO Generator page with this keyword pre-filled.
              </p>
              <button
                onClick={handleGenerateContent}
                className="bg-blue-500 text-white px-4 py-2 rounded-md hover:bg-blue-600 transition-colors w-full"
              >
                Go to SEO Generator
              </button>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  )
}

export default KeywordHistoryTable