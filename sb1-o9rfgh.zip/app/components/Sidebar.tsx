import React from 'react';
import { Home, Key, FileText, Search } from 'lucide-react';
import Link from 'next/link';
import { ThemeToggle } from './ThemeToggle';

const menuItems = [
  { name: 'Home', icon: <Home size={20} />, href: '/' },
  { name: 'API Key', icon: <Key size={20} />, href: '/api-key' },
  { name: 'SEO Generator', icon: <FileText size={20} />, href: '/seo-generator' },
  { name: 'Keyword Research', icon: <Search size={20} />, href: '/keyword-research' },
];

const Sidebar: React.FC = () => {
  return (
    <div className="bg-white dark:bg-gray-800 text-gray-800 dark:text-white w-64 min-h-screen p-4 shadow-lg">
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-2xl font-bold bg-gradient-to-r from-blue-500 to-purple-500 text-transparent bg-clip-text">SEO Tools</h1>
        <ThemeToggle />
      </div>
      <nav>
        <ul className="space-y-2">
          {menuItems.map((item) => (
            <li key={item.name}>
              <Link href={item.href} className="flex items-center space-x-2 p-2 rounded-md hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors duration-200">
                {item.icon}
                <span>{item.name}</span>
              </Link>
            </li>
          ))}
        </ul>
      </nav>
    </div>
  );
};

export default Sidebar;