import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { AlertTriangle, CheckCircle } from 'lucide-react';

interface TextAnalysisToolProps {
  content: string;
  plagiarismThreshold: number;
  aiGeneratedThreshold: number;
}

const TextAnalysisTool: React.FC<TextAnalysisToolProps> = ({ content, plagiarismThreshold, aiGeneratedThreshold }) => {
  const [wordCount, setWordCount] = useState(0);
  const [charCount, setCharCount] = useState(0);
  const [sentenceCount, setSentenceCount] = useState(0);
  const [paragraphCount, setParagraphCount] = useState(0);
  const [targetWordCount, setTargetWordCount] = useState(300);
  const [plagiarismScore, setPlagiarismScore] = useState(0);
  const [aiGeneratedScore, setAiGeneratedScore] = useState(0);

  useEffect(() => {
    const words = content.trim().split(/\s+/).length;
    const chars = content.length;
    const sentences = content.split(/[.!?]+/).filter(Boolean).length;
    const paragraphs = content.split(/\n\s*\n/).filter(Boolean).length;

    setWordCount(words);
    setCharCount(chars);
    setSentenceCount(sentences);
    setParagraphCount(paragraphs);

    // Simulated plagiarism check (replace with actual API call in production)
    setPlagiarismScore(Math.random() * 100);

    // Simulated AI-generated content detection (replace with actual API call in production)
    setAiGeneratedScore(Math.random() * 100);
  }, [content]);

  const progressPercentage = Math.min((wordCount / targetWordCount) * 100, 100);

  return (
    <div className="bg-white dark:bg-gray-800 rounded-lg shadow-lg p-4 mt-4">
      <h3 className="text-lg font-semibold mb-2 text-gray-800 dark:text-gray-200">Text Analysis</h3>
      <div className="grid grid-cols-2 gap-4 mb-4">
        <div>
          <p className="text-sm text-gray-600 dark:text-gray-400">Words: {wordCount}</p>
          <p className="text-sm text-gray-600 dark:text-gray-400">Characters: {charCount}</p>
        </div>
        <div>
          <p className="text-sm text-gray-600 dark:text-gray-400">Sentences: {sentenceCount}</p>
          <p className="text-sm text-gray-600 dark:text-gray-400">Paragraphs: {paragraphCount}</p>
        </div>
      </div>
      <div className="mb-2">
        <label htmlFor="targetWordCount" className="block text-sm font-medium text-gray-700 dark:text-gray-300">
          Target Word Count:
        </label>
        <input
          type="number"
          id="targetWordCount"
          value={targetWordCount}
          onChange={(e) => setTargetWordCount(Math.max(1, parseInt(e.target.value)))}
          className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-300 focus:ring focus:ring-blue-200 focus:ring-opacity-50 dark:bg-gray-700 dark:border-gray-600 dark:text-white"
        />
      </div>
      <div className="relative pt-1">
        <div className="flex mb-2 items-center justify-between">
          <div>
            <span className="text-xs font-semibold inline-block py-1 px-2 uppercase rounded-full text-blue-600 bg-blue-200 dark:text-blue-200 dark:bg-blue-800">
              Progress
            </span>
          </div>
          <div className="text-right">
            <span className="text-xs font-semibold inline-block text-blue-600 dark:text-blue-200">
              {progressPercentage.toFixed(1)}%
            </span>
          </div>
        </div>
        <div className="overflow-hidden h-2 mb-4 text-xs flex rounded bg-blue-200 dark:bg-blue-800">
          <motion.div
            style={{ width: `${progressPercentage}%` }}
            className="shadow-none flex flex-col text-center whitespace-nowrap text-white justify-center bg-blue-500"
            initial={{ width: 0 }}
            animate={{ width: `${progressPercentage}%` }}
            transition={{ duration: 0.5 }}
          />
        </div>
      </div>
      <div className="mt-4">
        <h4 className="text-md font-semibold mb-2 text-gray-800 dark:text-gray-200">Content Analysis</h4>
        <div className="flex items-center mb-2">
          <AlertTriangle size={20} className={`mr-2 ${plagiarismScore > plagiarismThreshold ? 'text-red-500' : 'text-green-500'}`} />
          <span className="text-sm text-gray-600 dark:text-gray-400">
            Plagiarism Score: {plagiarismScore.toFixed(1)}% (Threshold: {plagiarismThreshold}%)
          </span>
        </div>
        <div className="flex items-center">
          <CheckCircle size={20} className={`mr-2 ${aiGeneratedScore > aiGeneratedThreshold ? 'text-yellow-500' : 'text-green-500'}`} />
          <span className="text-sm text-gray-600 dark:text-gray-400">
            AI-Generated Content: {aiGeneratedScore.toFixed(1)}% (Threshold: {aiGeneratedThreshold}%)
          </span>
        </div>
      </div>
    </div>
  );
};

export default TextAnalysisTool;