import React, { useState } from 'react';
import { Copy, Check } from 'lucide-react';
import { toast } from 'react-hot-toast';

interface ContentPreviewProps {
  content: string;
}

const ContentPreview: React.FC<ContentPreviewProps> = ({ content }) => {
  const [copied, setCopied] = useState(false);

  const copyContent = () => {
    navigator.clipboard.writeText(content);
    setCopied(true);
    toast.success('Content copied to clipboard!');
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="mt-4">
      <div className="flex justify-between items-center mb-2">
        <h3 className="text-lg font-medium text-gray-700 dark:text-gray-300">Content Preview</h3>
        <button
          onClick={copyContent}
          className="flex items-center bg-blue-500 text-white py-1 px-3 rounded-md text-sm hover:bg-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-opacity-50 transition duration-200"
        >
          {copied ? (
            <>
              <Check size={16} className="mr-1" />
              Copied!
            </>
          ) : (
            <>
              <Copy size={16} className="mr-1" />
              Copy HTML
            </>
          )}
        </button>
      </div>
      <div className="bg-gray-100 dark:bg-gray-800 p-4 rounded-md overflow-auto max-h-96">
        <div dangerouslySetInnerHTML={{ __html: content }} className="prose dark:prose-invert max-w-none" />
      </div>
    </div>
  );
};

export default ContentPreview;