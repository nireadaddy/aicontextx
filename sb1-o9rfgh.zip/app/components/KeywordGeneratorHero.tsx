import React, { useState } from 'react'
import { OpenAI } from 'openai'
import { Loader2 } from 'lucide-react'
import { toast } from 'react-hot-toast'
import { useRouter } from 'next/navigation'
import { useApiKey } from '../hooks/useApiKey'

interface KeywordGeneratorHeroProps {
  addToHistory: (mainKeyword: string, relatedKeywords: string[]) => void
}

const KeywordGeneratorHero: React.FC<KeywordGeneratorHeroProps> = ({ addToHistory }) => {
  const [mainKeyword, setMainKeyword] = useState('')
  const [isLoading, setIsLoading] = useState(false)
  const { apiKey } = useApiKey()
  const router = useRouter()

  const generateKeywords = async () => {
    if (!apiKey) {
      toast.error('Please set your OpenAI API key in the API Key page')
      router.push('/api-key')
      return
    }
    if (!mainKeyword) {
      toast.error('Please enter a main keyword')
      return
    }
    setIsLoading(true)

    const openai = new OpenAI({ apiKey, dangerouslyAllowBrowser: true })

    try {
      const response = await openai.chat.completions.create({
        model: 'gpt-3.5-turbo',
        messages: [
          { role: 'system', content: 'You are an AI assistant specialized in SEO and keyword research.' },
          { role: 'user', content: `Generate 5 related keywords for "${mainKeyword}". Provide only the keywords, separated by commas.` },
        ],
      })

      const generatedKeywords = response.choices[0].message.content?.split(',').map(k => k.trim()) || []
      addToHistory(mainKeyword, generatedKeywords)
      toast.success('Keywords generated successfully!')
    } catch (error) {
      console.error('Error:', error)
      toast.error('An error occurred while generating keywords. Please check your API key.')
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="bg-white dark:bg-gray-800 rounded-lg shadow-lg p-6 mb-8">
      <h2 className="text-2xl font-semibold mb-4 text-gray-800 dark:text-gray-200">Keyword Generator</h2>
      <div className="flex items-center">
        <input
          type="text"
          value={mainKeyword}
          onChange={(e) => setMainKeyword(e.target.value)}
          placeholder="Enter main keyword"
          className="flex-grow px-4 py-2 rounded-l-md border border-gray-300 dark:border-gray-600 focus:outline-none focus:ring-2 focus:ring-blue-500 dark:bg-gray-700 dark:text-white"
        />
        <button
          onClick={generateKeywords}
          disabled={isLoading}
          className="bg-blue-500 text-white px-4 py-2 rounded-r-md hover:bg-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-opacity-50 transition duration-200"
        >
          {isLoading ? (
            <>
              <Loader2 className="animate-spin inline-block mr-2" size={16} />
              Generating...
            </>
          ) : (
            'Generate'
          )}
        </button>
      </div>
    </div>
  )
}

export default KeywordGeneratorHero