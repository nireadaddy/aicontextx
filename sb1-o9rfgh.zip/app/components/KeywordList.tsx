import React from 'react'
import { Loader2 } from 'lucide-react'
import { motion } from 'framer-motion'

interface KeywordListProps {
  keywords: string[]
  generateTitles: (keyword: string) => void
  isLoading: boolean
  loadingKeyword: string | null
}

const KeywordList: React.FC<KeywordListProps> = ({ keywords, generateTitles, isLoading, loadingKeyword }) => {
  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.3 }}
      className="bg-white dark:bg-gray-800 rounded-lg shadow-lg p-6 mb-8"
    >
      <h2 className="text-2xl font-semibold mb-4 text-gray-800 dark:text-gray-200">Suggested Keywords</h2>
      {keywords.length > 0 ? (
        <ul className="space-y-3">
          {keywords.map((keyword, index) => (
            <motion.li
              key={index}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, delay: index * 0.1 }}
              className="flex items-center justify-between bg-gray-50 dark:bg-gray-700 p-3 rounded-md"
            >
              <span className="text-gray-700 dark:text-gray-300">{keyword}</span>
              <button
                onClick={() => generateTitles(keyword)}
                disabled={isLoading || loadingKeyword === keyword}
                className={`bg-blue-500 text-white py-1 px-3 rounded-md text-sm hover:bg-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-opacity-50 transition duration-200 ${
                  (isLoading || loadingKeyword === keyword) ? 'opacity-50 cursor-not-allowed' : ''
                }`}
              >
                {loadingKeyword === keyword ? (
                  <>
                    <Loader2 className="animate-spin inline-block mr-2" size={16} />
                    Generating...
                  </>
                ) : (
                  'Generate Titles'
                )}
              </button>
            </motion.li>
          ))}
        </ul>
      ) : (
        <p className="text-gray-500 dark:text-gray-400">No keywords generated yet.</p>
      )}
    </motion.div>
  )
}

export default KeywordList