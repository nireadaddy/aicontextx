import React from 'react';
import { motion } from 'framer-motion';

interface ContentScoreChartProps {
  score: number;
}

const ContentScoreChart: React.FC<ContentScoreChartProps> = ({ score }) => {
  const getColor = (score: number) => {
    if (score < 30) return 'bg-red-500';
    if (score < 70) return 'bg-yellow-500';
    return 'bg-green-500';
  };

  return (
    <div className="relative pt-1">
      <div className="flex mb-2 items-center justify-between">
        <div>
          <span className="text-xs font-semibold inline-block py-1 px-2 uppercase rounded-full text-blue-600 bg-blue-200 dark:text-blue-200 dark:bg-blue-800">
            SEO Score
          </span>
        </div>
        <div className="text-right">
          <span className="text-xs font-semibold inline-block text-blue-600 dark:text-blue-200">
            {score}%
          </span>
        </div>
      </div>
      <div className="overflow-hidden h-2 mb-4 text-xs flex rounded bg-blue-200 dark:bg-blue-800">
        <motion.div
          initial={{ width: 0 }}
          animate={{ width: `${score}%` }}
          transition={{ duration: 0.5, ease: "easeOut" }}
          className={`shadow-none flex flex-col text-center whitespace-nowrap text-white justify-center ${getColor(score)}`}
        ></motion.div>
      </div>
    </div>
  );
};

export default ContentScoreChart;