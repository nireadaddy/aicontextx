import React, { useState, useEffect } from 'react';

interface OutputDisplayProps {
  output: string;
  isLoading: boolean;
}

const OutputDisplay: React.FC<OutputDisplayProps> = ({ output, isLoading }) => {
  const [displayedOutput, setDisplayedOutput] = useState('');
  const [currentIndex, setCurrentIndex] = useState(0);

  useEffect(() => {
    if (!isLoading && output) {
      const timer = setTimeout(() => {
        if (currentIndex < output.length) {
          setDisplayedOutput((prev) => prev + output[currentIndex]);
          setCurrentIndex((prev) => prev + 1);
        }
      }, 25); // Adjust this value to change typing speed

      return () => clearTimeout(timer);
    }
  }, [isLoading, output, currentIndex]);

  useEffect(() => {
    if (isLoading) {
      setDisplayedOutput('');
      setCurrentIndex(0);
    }
  }, [isLoading]);

  return (
    <div className="mt-6">
      <h2 className="text-lg font-medium text-gray-900 mb-2">Output</h2>
      {isLoading ? (
        <div className="animate-pulse flex space-x-4">
          <div className="flex-1 space-y-4 py-1">
            <div className="h-4 bg-gray-200 rounded w-3/4"></div>
            <div className="space-y-2">
              <div className="h-4 bg-gray-200 rounded"></div>
              <div className="h-4 bg-gray-200 rounded w-5/6"></div>
            </div>
          </div>
        </div>
      ) : (
        <div className="bg-gray-50 rounded-lg p-4 min-h-[100px]">
          <pre className="whitespace-pre-wrap typewriter">{displayedOutput}</pre>
        </div>
      )}
    </div>
  );
};

export default OutputDisplay;