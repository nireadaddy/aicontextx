'use client'

import React, { useState, useEffect } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { X } from 'lucide-react'

const steps = [
  {
    title: 'Welcome to SEO Content Generator',
    description: 'Boost your content creation and SEO strategy with AI-powered tools.',
    image: '/onboarding-welcome.svg',
  },
  {
    title: 'Generate Keywords',
    description: 'Start by entering a main keyword to generate related keywords and ideas.',
    image: '/onboarding-keywords.svg',
  },
  {
    title: 'Create Optimized Content',
    description: 'Use our AI to generate SEO-friendly titles and content for your keywords.',
    image: '/onboarding-content.svg',
  },
]

const OnboardingModal: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false)
  const [currentStep, setCurrentStep] = useState(0)

  useEffect(() => {
    const hasSeenOnboarding = localStorage.getItem('hasSeenOnboarding')
    if (!hasSeenOnboarding) {
      setIsOpen(true)
    }
  }, [])

  const closeModal = () => {
    setIsOpen(false)
    localStorage.setItem('hasSeenOnboarding', 'true')
  }

  const nextStep = () => {
    if (currentStep < steps.length - 1) {
      setCurrentStep(currentStep + 1)
    } else {
      closeModal()
    }
  }

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50"
        >
          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.9, opacity: 0 }}
            className="bg-white dark:bg-gray-800 rounded-lg p-8 max-w-md w-full"
          >
            <button
              onClick={closeModal}
              className="absolute top-4 right-4 text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200"
            >
              <X size={24} />
            </button>
            <img
              src={steps[currentStep].image}
              alt={steps[currentStep].title}
              className="w-full h-48 object-contain mb-6"
            />
            <h2 className="text-2xl font-bold mb-4 text-gray-800 dark:text-gray-200">
              {steps[currentStep].title}
            </h2>
            <p className="text-gray-600 dark:text-gray-400 mb-6">
              {steps[currentStep].description}
            </p>
            <div className="flex justify-between items-center">
              <div className="flex space-x-2">
                {steps.map((_, index) => (
                  <div
                    key={index}
                    className={`w-2 h-2 rounded-full ${
                      index === currentStep ? 'bg-blue-500' : 'bg-gray-300 dark:bg-gray-600'
                    }`}
                  />
                ))}
              </div>
              <button
                onClick={nextStep}
                className="bg-blue-500 text-white px-4 py-2 rounded-md hover:bg-blue-600 transition-colors"
              >
                {currentStep === steps.length - 1 ? 'Get Started' : 'Next'}
              </button>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  )
}

export default OnboardingModal