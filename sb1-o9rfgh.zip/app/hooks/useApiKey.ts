import { useState, useEffect } from 'react'

export function useApiKey() {
  const [apiKey, setApiKey] = useState('')
  const [isLoaded, setIsLoaded] = useState(false)

  useEffect(() => {
    const storedApiKey = localStorage.getItem('openai_api_key')
    if (storedApiKey) {
      setApiKey(storedApiKey)
    }
    setIsLoaded(true)
  }, [])

  const updateApiKey = (newApiKey: string) => {
    setApiKey(newApiKey)
    localStorage.setItem('openai_api_key', newApiKey)
  }

  return { apiKey, updateApiKey, isLoaded }
}