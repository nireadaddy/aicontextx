'use client'

import React, { useState, useEffect } from 'react'
import Link from 'next/link'
import { FileText, Search, ArrowRight } from 'lucide-react'
import { motion } from 'framer-motion'
import KeywordGeneratorHero from './components/KeywordGeneratorHero'
import KeywordHistoryTable from './components/KeywordHistoryTable'
import { useApiKey } from './hooks/useApiKey'
import { useRouter } from 'next/navigation'

const menuItems = [
  { name: 'SEO Content Generator', icon: <FileText size={24} />, href: '/seo-generator' },
  { name: 'Keyword Research', icon: <Search size={24} />, href: '/keyword-research' },
]

export default function Home() {
  const [keywordHistory, setKeywordHistory] = useState<{ mainKeyword: string, relatedKeywords: string[], date: string }[]>([])
  const { apiKey, isLoaded } = useApiKey()
  const router = useRouter()

  useEffect(() => {
    const storedHistory = localStorage.getItem('keywordHistory')
    if (storedHistory) {
      setKeywordHistory(JSON.parse(storedHistory))
    }
  }, [])

  useEffect(() => {
    if (isLoaded && !apiKey) {
      router.push('/api-key')
    }
  }, [isLoaded, apiKey, router])

  const addToHistory = (mainKeyword: string, relatedKeywords: string[]) => {
    const newEntry = {
      mainKeyword,
      relatedKeywords,
      date: new Date().toLocaleString()
    }
    const updatedHistory = [newEntry, ...keywordHistory].slice(0, 10)
    setKeywordHistory(updatedHistory)
    localStorage.setItem('keywordHistory', JSON.stringify(updatedHistory))
  }

  if (!isLoaded) {
    return null
  }

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <h1 className="text-4xl font-bold mb-8 text-gray-800 dark:text-gray-200">SEO Content Generator</h1>
      <KeywordGeneratorHero addToHistory={addToHistory} />
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-8">
        {menuItems.map((item) => (
          <Link key={item.name} href={item.href}>
            <motion.div
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="bg-white dark:bg-gray-800 rounded-lg shadow-lg p-6 flex items-center justify-between cursor-pointer"
            >
              <div className="flex items-center">
                {item.icon}
                <span className="ml-4 text-xl font-semibold text-gray-800 dark:text-gray-200">{item.name}</span>
              </div>
              <ArrowRight size={24} className="text-gray-500 dark:text-gray-400" />
            </motion.div>
          </Link>
        ))}
      </div>
      <h2 className="text-2xl font-semibold mb-4 text-gray-800 dark:text-gray-200">Recent Keyword History</h2>
      <KeywordHistoryTable history={keywordHistory} />
    </div>
  )
}