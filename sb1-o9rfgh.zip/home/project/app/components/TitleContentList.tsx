import React from 'react'
import { Loader2 } from 'lucide-react'
import ContentPreview from './ContentPreview'
import ContentScoreChart from './ContentScoreChart'
import TextAnalysisTool from './TextAnalysisTool'
import { motion } from 'framer-motion'

interface TitleContentListProps {
  titles: { [key: string]: string[] }
  contents: { [key: string]: { content: string; score: number; density: number } }
  generateContent: (keyword: string, title: string) => void
  isLoading: boolean
  loadingTitle: string | null
}

const TitleContentList: React.FC<TitleContentListProps> = ({ titles, contents, generateContent, isLoading, loadingTitle }) => {
  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.3 }}
      className="bg-white dark:bg-gray-800 rounded-lg shadow-lg p-6"
    >
      <h2 className="text-2xl font-semibold mb-4 text-gray-800 dark:text-gray-200">Generated Titles and Content</h2>
      {Object.entries(titles).map(([keyword, titleList]) => (
        <motion.div
          key={keyword}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3 }}
          className="mb-6"
        >
          <h3 className="text-lg font-medium mb-2 text-gray-700 dark:text-gray-300">{keyword}</h3>
          <ul className="space-y-4">
            {titleList.map((title, index) => (
              <motion.li
                key={index}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3, delay: index * 0.1 }}
                className="bg-gray-50 dark:bg-gray-700 p-4 rounded-md"
              >
                <h4 className="font-medium text-gray-600 dark:text-gray-400">{title}</h4>
                {contents[title] ? (
                  <div className="mt-2">
                    <ContentPreview content={contents[title].content} />
                    <div className="mt-2">
                      <ContentScoreChart score={contents[title].score} />
                    </div>
                    <div className="mt-2 flex justify-between text-sm text-gray-600 dark:text-gray-400">
                      <span>Keyword Density: {contents[title].density.toFixed(2)}%</span>
                    </div>
                    <TextAnalysisTool content={contents[title].content} />
                  </div>
                ) : (
                  <button
                    onClick={() => generateContent(keyword, title)}
                    disabled={isLoading || loadingTitle === title}
                    className={`mt-2 bg-green-500 text-white py-1 px-3 rounded-md text-sm hover:bg-green-600 focus:outline-none focus:ring-2 focus:ring-green-500 focus:ring-opacity-50 transition duration-200 ${
                      (isLoading || loadingTitle === title) ? 'opacity-50 cursor-not-allowed' : ''
                    }`}
                  >
                    {loadingTitle === title ? (
                      <>
                        <Loader2 className="animate-spin inline-block mr-2" size={16} />
                        Generating...
                      </>
                    ) : (
                      'Generate Content'
                    )}
                  </button>
                )}
              </motion.li>
            ))}
          </ul>
        </motion.div>
      ))}
      {Object.keys(titles).length === 0 && (
        <p className="text-gray-500 dark:text-gray-400">No titles generated yet.</p>
      )}
    </motion.div>
  )
}

export default TitleContentList