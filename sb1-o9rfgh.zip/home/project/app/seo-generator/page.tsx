'use client'

import { useState, useEffect } from 'react'
import { useSearchParams, useRouter } from 'next/navigation'
import { OpenAI } from 'openai'
import { Loader2 } from 'lucide-react'
import KeywordList from '../components/KeywordList'
import TitleContentList from '../components/TitleContentList'
import { toast } from 'react-hot-toast'
import { motion } from 'framer-motion'
import { useApiKey } from '../hooks/useApiKey'

const models = ['gpt-4', 'gpt-4-32k', 'gpt-3.5-turbo', 'gpt-3.5-turbo-16k', 'gpt-4o']
const tones = ['Professional', 'Casual', 'Friendly', 'Authoritative', 'Humorous']

export default function SeoGeneratorPage() {
  const [selectedModel, setSelectedModel] = useState(models[0])
  const [selectedTone, setSelectedTone] = useState(tones[0])
  const [mainKeyword, setMainKeyword] = useState('')
  const [keywords, setKeywords] = useState<string[]>([])
  const [titles, setTitles] = useState<{ [key: string]: string[] }>({})
  const [contents, setContents] = useState<{ [key: string]: { content: string; score: number; density: number } }>({})
  const [isLoading, setIsLoading] = useState(false)
  const [loadingKeyword, setLoadingKeyword] = useState<string | null>(null)
  const [loadingTitle, setLoadingTitle] = useState<string | null>(null)

  const searchParams = useSearchParams()
  const router = useRouter()
  const { apiKey } = useApiKey()

  useEffect(() => {
    const keyword = searchParams.get('keyword')
    if (keyword) {
      setMainKeyword(decodeURIComponent(keyword))
    }
  }, [searchParams])

  const generateKeywords = async (keyword: string) => {
    if (!apiKey) {
      toast.error('Please set your OpenAI API key in the API Key page')
      router.push('/api-key')
      return
    }

    setIsLoading(true)
    setKeywords([])

    try {
      const openai = new OpenAI({ apiKey, dangerouslyAllowBrowser: true })
      const response = await openai.chat.completions.create({
        model: selectedModel,
        messages: [
          { role: 'system', content: `You are an AI assistant specialized in SEO and keyword research. Respond in a ${selectedTone.toLowerCase()} tone.` },
          { role: 'user', content: `Generate 5 related keywords for "${keyword}". Provide only the keywords, separated by commas.` },
        ],
      })

      const generatedKeywords = response.choices[0].message.content?.split(',').map(k => k.trim()) || []
      setKeywords(generatedKeywords)
      toast.success('Keywords generated successfully!')
    } catch (error) {
      console.error('Error:', error)
      toast.error('An error occurred while generating keywords. Please check your API key.')
    } finally {
      setIsLoading(false)
    }
  }

  const generateTitles = async (keyword: string) => {
    setLoadingKeyword(keyword)
    try {
      const openai = new OpenAI({ apiKey, dangerouslyAllowBrowser: true })
      const response = await openai.chat.completions.create({
        model: selectedModel,
        messages: [
          { role: 'system', content: `You are an AI assistant specialized in SEO and content creation. Respond in a ${selectedTone.toLowerCase()} tone.` },
          { role: 'user', content: `Generate 3 SEO-optimized titles for an article about "${keyword}". Provide only the titles, separated by semicolons.` },
        ],
      })

      const generatedTitles = response.choices[0].message.content?.split(';').map(t => t.trim()) || []
      setTitles(prevTitles => ({ ...prevTitles, [keyword]: generatedTitles }))
      toast.success('Titles generated successfully!')
    } catch (error) {
      console.error('Error:', error)
      toast.error('An error occurred while generating titles.')
    } finally {
      setLoadingKeyword(null)
    }
  }

  const generateContent = async (keyword: string, title: string) => {
    setLoadingTitle(title)
    try {
      const openai = new OpenAI({ apiKey, dangerouslyAllowBrowser: true })
      const response = await openai.chat.completions.create({
        model: selectedModel,
        messages: [
          { role: 'system', content: `You are an AI assistant specialized in SEO and content creation. Respond in a ${selectedTone.toLowerCase()} tone.` },
          { role: 'user', content: `Generate a 300-word SEO-optimized article for the title "${title}" focusing on the keyword "${keyword}". Include HTML tags for headings and paragraphs.` },
        ],
      })

      const generatedContent = response.choices[0].message.content || ''
      const score = Math.floor(Math.random() * 41) + 60 // Random score between 60 and 100
      const density = (generatedContent.toLowerCase().split(keyword.toLowerCase()).length - 1) / generatedContent.split(' ').length * 100

      setContents(prevContents => ({
        ...prevContents,
        [title]: { content: generatedContent, score, density }
      }))
      toast.success('Content generated successfully!')
    } catch (error) {
      console.error('Error:', error)
      toast.error('An error occurred while generating content.')
    } finally {
      setLoadingTitle(null)
    }
  }

  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-8 text-gray-800 dark:text-gray-200">SEO Content Generator</h1>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <div className="mb-6 grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label htmlFor="model" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
              Select Model
            </label>
            <select
              id="model"
              value={selectedModel}
              onChange={(e) => setSelectedModel(e.target.value)}
              className="w-full px-4 py-2 rounded-md border border-gray-300 dark:border-gray-600 focus:outline-none focus:ring-2 focus:ring-blue-500 dark:bg-gray-700 dark:text-white"
            >
              {models.map((model) => (
                <option key={model} value={model}>{model === 'gpt-4o' ? 'GPT-4 Omni' : model}</option>
              ))}
            </select>
          </div>
          <div>
            <label htmlFor="tone" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
              Select Tone
            </label>
            <select
              id="tone"
              value={selectedTone}
              onChange={(e) => setSelectedTone(e.target.value)}
              className="w-full px-4 py-2 rounded-md border border-gray-300 dark:border-gray-600 focus:outline-none focus:ring-2 focus:ring-blue-500 dark:bg-gray-700 dark:text-white"
            >
              {tones.map((tone) => (
                <option key={tone} value={tone}>{tone}</option>
              ))}
            </select>
          </div>
        </div>
        <div className="mb-6">
          <label htmlFor="mainKeyword" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
            Main Keyword
          </label>
          <div className="flex">
            <input
              type="text"
              id="mainKeyword"
              value={mainKeyword}
              onChange={(e) => setMainKeyword(e.target.value)}
              className="flex-grow px-4 py-2 rounded-l-md border border-gray-300 dark:border-gray-600 focus:outline-none focus:ring-2 focus:ring-blue-500 dark:bg-gray-700 dark:text-white"
              placeholder="Enter your main keyword"
            />
            <button
              onClick={() => generateKeywords(mainKeyword)}
              disabled={isLoading || !mainKeyword}
              className="bg-blue-500 text-white px-4 py-2 rounded-r-md hover:bg-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-opacity-50 transition duration-200 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isLoading ? (
                <>
                  <Loader2 className="animate-spin inline-block mr-2" size={16} />
                  Generating...
                </>
              ) : (
                'Generate'
              )}
            </button>
          </div>
        </div>
        <KeywordList
          keywords={keywords}
          generateTitles={generateTitles}
          isLoading={isLoading}
          loadingKeyword={loadingKeyword}
        />
        <TitleContentList
          titles={titles}
          contents={contents}
          generateContent={generateContent}
          isLoading={isLoading}
          loadingTitle={loadingTitle}
        />
      </motion.div>
    </div>
  )
}